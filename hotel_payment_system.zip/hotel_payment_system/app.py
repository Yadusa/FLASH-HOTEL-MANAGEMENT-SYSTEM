from flask import Flask, render_template, request, redirect, url_for, flash
from datetime import datetime

app = Flask(__name__)
app.secret_key = "hotel_secret_key"

# In-memory transaction history (for demo)
transactions = []

def luhn_check(card_number):
    """Validate credit card number using Luhn algorithm."""
    card_number = card_number.replace(" ", "")
    if not card_number.isdigit():
        return False
    digits = [int(x) for x in card_number]
    for i in range(len(digits) - 2, -1, -2):
        digits[i] *= 2
        if digits[i] > 9:
            digits[i] -= 9
    return sum(digits) % 10 == 0

@app.route("/")
def home():
    return render_template("payment.html")

@app.route("/pay", methods=["POST"])
def pay():
    name = request.form["name"]
    card_number = request.form["card_number"]
    expiry = request.form["expiry"]
    cvv = request.form["cvv"]
    amount = request.form["amount"]

    # Validate input
    if not all([name, card_number, expiry, cvv, amount]):
        flash(" Please fill in all fields.")
        return redirect(url_for("home"))

    if not luhn_check(card_number):
        flash(" Invalid card number.")
        return redirect(url_for("home"))

    try:
        exp_month, exp_year = expiry.split("/")
        exp_date = datetime(int("20" + exp_year), int(exp_month), 1)
        if exp_date < datetime.now():
            flash(" Card has expired.")
            return redirect(url_for("home"))
    except:
        flash(" Invalid expiry format (use MM/YY).")
        return redirect(url_for("home"))

    if len(cvv) != 3 or not cvv.isdigit():
        flash(" CVV must be a 3-digit number.")
        return redirect(url_for("home"))

    # Simulate transaction success
    transaction = {
        "name": name,
        "card_number": f"**** **** **** {card_number[-4:]}",
        "amount": amount,
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    transactions.append(transaction)

    return render_template("success.html", transaction=transaction)

if __name__ == "__main__":
    app.run(debug=True)
